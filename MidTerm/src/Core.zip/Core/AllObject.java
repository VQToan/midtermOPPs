package Core;
//========= object nay co the chua 2 doi tuong Room va Customer===============//
public class AllObject {
	private Customer customer;
	private Room room;
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room rom) {
		this.room = rom;
	}
}
