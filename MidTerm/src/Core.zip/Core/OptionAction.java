package Core;

public class OptionAction {
	public void Oder(String typeRoom) {
		
	}
}
